package com.example.myapplication

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Getting references to UI elements
        val etPrincipal = findViewById<EditText>(R.id.etPrincipal)
        val etRate = findViewById<EditText>(R.id.etRate)
        val etTime = findViewById<EditText>(R.id.etTime)
        val rbSimple = findViewById<RadioButton>(R.id.rbSimple)
        val rbCompound = findViewById<RadioButton>(R.id.rbCompound)
        val tvInterest = findViewById<TextView>(R.id.tvInterest)
        val tvTotalAmount = findViewById<TextView>(R.id.tvTotalAmount)

        // Function to calculate and display the interest and total amount
        fun calculateInterest() {
            // Get the user inputs
            val principal = etPrincipal.text.toString().toDoubleOrNull()
            val rate = etRate.text.toString().toDoubleOrNull()
            val time = etTime.text.toString().toDoubleOrNull()

            // Ensure all inputs are valid
            if (principal != null && rate != null && time != null) {
                val interest: Double
                val totalAmount: Double

                // Check if the user selected Simple or Compound interest
                if (rbSimple.isChecked) {
                    // Simple Interest Formula: SI = P * R * T / 100
                    interest = (principal * rate * time) / 100
                } else {
                    // Compound Interest Formula: CI = P * (1 + R/n)^nt - P
                    // Assuming n (number of times compounded) is yearly (n = 1)
                    interest = principal * Math.pow(1 + (rate / 100), time) - principal
                }

                // Calculate total amount
                totalAmount = principal + interest

                // Display the interest and total amount
                tvInterest.text = "Interest: $interest"
                tvTotalAmount.text = "Total Amount: $totalAmount"
            }
        }

        // Adding a TextWatcher to update the result as soon as user inputs change
        val textWatcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                calculateInterest()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }

        // Adding TextWatchers to EditTexts
        etPrincipal.addTextChangedListener(textWatcher)
        etRate.addTextChangedListener(textWatcher)
        etTime.addTextChangedListener(textWatcher)

        // Adding OnCheckedChangeListener to RadioGroup to calculate interest when selection changes
        val rgInterestType = findViewById<RadioGroup>(R.id.rgInterestType)
        rgInterestType.setOnCheckedChangeListener { _, _ -> calculateInterest() }
    }
}